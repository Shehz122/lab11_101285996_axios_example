import logo from './logo.svg';
import './App.css';
import UserList from './UserList';

function App() {
  return (
    <div>
      <h1>Week11 - Axios Example</h1>
      <UserList/>
    </div>
  );
}

export default App;
